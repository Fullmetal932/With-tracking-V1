export interface PDFGeneratorResult {
  previewUrl: string;
  downloadUrl: string;
}