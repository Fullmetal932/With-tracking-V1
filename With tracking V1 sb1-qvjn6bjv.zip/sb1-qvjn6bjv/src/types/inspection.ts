export interface InspectionFormData {
  address: string;
  city: string;
  zip: string;
  deviceType: string;
  deviceSize: string;
  serialNumber: string;
  test1A: string;
  test1B: string;
  test3: string;
  notes: string;
  secondTestNF: boolean;
}